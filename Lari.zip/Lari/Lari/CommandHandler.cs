﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System.Threading.Tasks;
using System;

namespace Lari
{
    public class UkázkaPříkazů : ModuleBase
    {


        [Command("pomoc")]
        public async Task Help()
        {
            //Odpověď můžeš poslat v embedu, za chvíli ukážu jak to vypadá
            var embedbuilder = new EmbedBuilder()
            .WithTitle("Pomoc je na cestě!")
            .WithColor(new Color(0x056d13))
            .WithFooter(footer =>
            {
                footer
                    .WithText("Command Help");
            })

            .AddField("Prefix je:", "L? nebo @Lari#7454")
            .AddField("L?papousek", "Zopakuje zprávu... jako papoušek XD")
            .AddField("L?welcome", "Pozdraví vás!")
            .AddField("L?nasrat", "Vyzkoušej sám!")
            .AddField("L?servers", "Napíše všechny servery, na kterých je připojený(Užitečný příkaz)")
            .AddField("L?kys", "Jsi povinný to zkusit!")
            .AddField("L?synjenamegacraftuowner", "Napíše, co Syn doopravdy je")
            .AddField("L?say", "Consolový příkaz, pouze pro člověka, který mě spouští")
            .AddField("Programátor Bota: Šebestíček#8254", "Pomocný Programátor Bota: ÁkaCrafter CZ#2684")
            .AddField("Autorská práva se mohou vztahovat na každého, kdo okopíruje bota nebo jeho část/i", "*Nesmíte bota používat pro komerční účely.*")
            .AddField("**Vyrobeno týmem NGST**", "*Next Generation Software Technologies*");
            var embed = embedbuilder.Build();

            await Context.Channel.SendMessageAsync("", embed: embed).ConfigureAwait(false);
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()); //tohle ti napíše do konzole, že  je bot ready.
        }
        //tady je příkaz, který zopakuje zprávu - jako papoušek :D
        [Command("papousek")]
        public async Task Papoušek([Remainder] string echo) //string echo = vytvoření proměnné pro jednotlivý úkol, v tomto případě je to argument
        {
            await Context.Channel.SendMessageAsync(echo);
            var embedbuilder = new EmbedBuilder()
            .WithTitle(echo);


            var embed = embedbuilder.Build();

            await Context.Channel.SendMessageAsync("", embed: embed).ConfigureAwait(false);
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }
        [Command("welcome")]
        public async Task Welcome()
        {
            await Context.Channel.SendMessageAsync("Ahoj "+ Context.User);
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }

       
       
        [Command("nasrat")]
        public async Task Nasrat()
        {
            await Context.Channel.SendMessageAsync("Naser si!");
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }
        [Command("servers")]
        public async Task Servers()
        {
            var embedbuilder = new EmbedBuilder()
            .WithTitle("All Connected Servers:")
            .WithColor(new Color(0x056d13))
            .WithFooter(footer =>
            {
                footer
                    .WithText("Servers Connected");
            })

            .AddField("Nothing to see here!", "Servery již brzy!");
             var embed = embedbuilder.Build();

            await Context.Channel.SendMessageAsync("", embed: embed).ConfigureAwait(false);
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }
        [Command("kys")]
        public async Task Kill()
        {
            await Context.Channel.SendMessageAsync(Context.User + " Kill yourself, before I Kill You");
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }
        [Command("synjenamegacraftuowner")]
        public async Task Megacraft()
        {
            await Context.Channel.SendMessageAsync("Syn je na Megacraftu Owner. To máš teda pravdu " + Context.User + ".");
            Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
        }
        [Command("say")]
        public async Task Say()
        {
            Console.Write("[INFO] Použit příkaz say, co chcete napsat?: ");
            await Context.Channel.SendMessageAsync("⚠Pozor! Tento příkaz může použít jen Majitel bota a funguje pouze na kanál, ve kterém je příkaz vyvolán! Pro zrušení příkazu kontaktujte majitele: Šebestíček#8254. ⚠");
            string text = Console.ReadLine();
            if (text == "cancel")
            {
                await Context.Channel.SendMessageAsync("⛔Příkaz zrušen!⛔ Zrušeno v: " + DateTime.Now.ToShortDateString() + " ve: " + DateTime.Now.ToShortTimeString());
                Console.WriteLine("[INFO] Příkaz zrušen! Čas zrušení: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
            }
            else
            {
                await Context.Channel.SendMessageAsync(text + "*" + Context.User + "*");
                var embedbuilder = new EmbedBuilder()
                  .WithTitle(text + "*" + Context.User + "*");


                var embed = embedbuilder.Build();

                await Context.Channel.SendMessageAsync("", embed: embed).ConfigureAwait(false);
                Console.WriteLine("[INFO] Příkaz použit: " + "Příkaz: " + Context.Message + " Od: " + Context.User + " Kanál: " + Context.Channel + " Server: " + Context.Guild + " Čas použití: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString());
            }

        }
        }
}